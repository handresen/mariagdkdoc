﻿#X:\PDMT\2013\Leveranse\20130603\Map\Vector\PDMT\N50\0101Halden
$folders = Get-ChildItem "\\data\GeoData\PDMT\2014\M4M\FKB_m4m"
$kommuner = Import-Csv "\\data\GeoData\PDMT\2014\Support Tools\FKB\Kommune.txt" -Delimiter ';'

foreach($folder in $folders)
{
	$fyFolders = Get-ChildItem $folder.FullName
	
	foreach($fyFolder in $fyFolders)
	{
		if ($fyFolder.Name -ne "PDMT")
		{
			$files = Get-ChildItem $fyFolder.FullName
			foreach ($file in $files)
			{
				$kommuneNr = 0
				[int32]::TryParse( $file.name.Remove(0,6).Remove(4), [ref]$kommuneNr)
				$kommune = $kommuner | Where-Object {$_.Komm -eq $kommuneNr}
				$newFolderName = $file.name.Remove(0,6).Remove(4) + $kommune.KommuneNavn
				

				$newFileName = $kommuneNr.ToString() + $file.Name.Remove(0, 10)
				
				$destination = Join-Path $folder.FullName "PDMT\Utrykning\N5" 
				$destination = Join-Path $destination $newFolderName
				$newPath = Join-Path $destination $newFileName
							
				New-Item -ItemType directory -Path $destination -Force
				Move-Item -Path $file.FullName -Destination $newPath -Force
			}
		}
	}
}