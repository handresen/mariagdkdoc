﻿
function Merge-ShpFiles ($type, $files, $nlt)
{
#$type = $args[1]
#$files = @($args[0])
if($files -ne $null )
{
if($files[0] -ne $null)
{
foreach ($file in $files)
{	
	$folder = $file.Directory
	$fileBaseName = $folder.BaseName + $type
	$mergePath = $tmpFolder
#	$nlt = $args[2]

	if($file -eq $files[0])
	{
		if(!(Test-Path $mergePath))
		{
			New-Item -ItemType directory -Path $mergePath
		}
		$arguments = @('-f "ESRI Shapefile"')
		$arguments += Join-Path $mergePath ($fileBaseName + '.shp')
		$arguments += $file
		$arguments += '-nlt ' + $nlt
		

		#	Start-Job -Name DoSomething -ScriptBlock $scriptBlock -ArgumentList (,$arguments)
#	Get-Job -Name DoSomething | Wait-Job | Receive-Job
	$pinfo = New-Object System.Diagnostics.ProcessStartInfo
	$pinfo.FileName = "F:\tfs2010\MARIA\Third party\gdal-1.9.2\apps\ogr2ogr.exe"
	$pinfo.RedirectStandardError = $true
	$pinfo.RedirectStandardOutput = $true
	$pinfo.UseShellExecute = $false
	$pinfo.Arguments = $arguments
	
	$p = New-Object System.Diagnostics.Process
	$p.StartInfo = $pinfo
	$p.Start() | Out-Null
	#Do Other Stuff Here....
	$p.WaitForExit()
	Write-Output ('Exit Code: ' + $p.ExitCode + ' : ' + $file.FullName  )
	if($p.ExitCode -ne 0)
	{
		('Exit Code: ' + $p.ExitCode + ' : ' + $file.FullName  ) | Out-File $logFile -Append -Force 
		$errorMessage = $p.StandardError.ReadToEnd()
		$errorMessage | Out-File $logFile -Append -Force 
		Write-Output $errorMessage
	}
		
		$inputargs = @(Join-Path $mergePath ($fileBaseName + '.shp'))
		$inputargs += "-al"
		$inputargs += "-so"
		$inputargs += "-geom=NO"
		
		#&"F:\Temp\EchoArgs.exe" $inputargs
		$info = &"F:\tfs2010\MARIA\Third party\gdal-1.9.2\apps\ogrinfo.exe" $inputargs
		$i = -1
		while(!$info[$i].startswith(' '))
		{
			$i--
		}
		$mergeFileAttributes = $info[-1..($i+1)]
		
		
		
	}
	else
	{
		$fileAttributes = @()
		
		
		$inputargs = @($file)
		$inputargs += "-al"
		$inputargs += "-so"
		$inputargs += "-geom=NO"
		
		
		#&"F:\Temp\EchoArgs.exe" $inputargs
		$info = &"F:\tfs2010\MARIA\Third party\gdal-1.9.2\apps\ogrinfo.exe" $inputargs
		$i = -1
		while(!$info[$i].startswith(' '))
		{
			$i--
		}
		$fileAttributes = $info[-1..($i+1)]
		
		foreach($attribute in $fileAttributes)
		{
			if ($mergeFileAttributes -notcontains $attribute)
			{
			$inputargs = @(Join-Path $mergePath ($fileBaseName + '.shp'))
			$attr = (($attribute -split ' ')[0]).Trim(':,"')
			$typeA = ($attribute -split ' ')[1]
			$length = ($attribute -split ' ')[2].Trim('(',')')
			
			switch ($typeA)
				{
				'string' {$attrType = 'character(' + $length + ')' }
				'integer' {$attrType = 'integer' }
				default {
						Write-Error $attribute
						$attribute | Out-File $logFile -Append -Force 
						}
				}
			$inputargs += $fileBaseName
			$inputargs += "$attr $attrType"
			
			
			#$inputargs += "-sql `\""ALTER TABLE $fileBaseName ADD COLUMN $attr $attrType`\"""
			
			#$inputargs += "-sql \`"SELECT * FROM $fileBaseName\`'"
			#&"F:\Temp\EchoArgs.exe" $inputargs
			#&"F:\tfs2010\MARIA\Third party\gdal-1.9.2\apps\ogrinfo.exe" $inputargs 
			$retVal = &"F:\RunOgrInfo.bat" $inputargs
			$mergeFileAttributes += $attribute
			}
		}
		
		
  
  
		$arguments = @('-update')
		$arguments += '-append'
		$arguments += '-f "ESRI Shapefile"'
		$arguments += Join-Path $mergePath ($fileBaseName + '.shp')
		$arguments += $file
		$arguments += '-nlt ' + $nlt
		
		#	Start-Job -Name DoSomething -ScriptBlock $scriptBlock -ArgumentList (,$arguments)
#	Get-Job -Name DoSomething | Wait-Job | Receive-Job
	$pinfo = New-Object System.Diagnostics.ProcessStartInfo
	$pinfo.FileName = "F:\tfs2010\MARIA\Third party\gdal-1.9.2\apps\ogr2ogr.exe"
	$pinfo.RedirectStandardError = $true
	$pinfo.RedirectStandardOutput = $true
	$pinfo.UseShellExecute = $false
	$pinfo.Arguments = $arguments
	
	$p = New-Object System.Diagnostics.Process
	$p.StartInfo = $pinfo
	$p.Start() | Out-Null
	#Do Other Stuff Here....
	$p.WaitForExit()
	Write-Output ('Exit Code: ' + $p.ExitCode + ' : ' + $file.FullName  )
	if($p.ExitCode -ne 0)
	{
		('Exit Code: ' + $p.ExitCode + ' : ' + $file.FullName  ) | Out-File $logFile -Append -Force 
		$errorMessage = $p.StandardError.ReadToEnd()
		$errorMessage | Out-File $logFile -Append -Force 
		Write-Output $errorMessage
	}
	}
	
#	$scriptBlock = 
#	{
#		param( [String[]] $p)
#		[String] $as 
#		foreach($a in $p)
#		{
#			$as += $a + ' '
#		}
#		$exe = "F:\tfs2010\MARIA\Third party\gdal-1.9.2\apps\ogr2ogr.exe"
#		$exe = "F:\Temp\EchoArgs.exe"
#		Write-output $as
#		&$exe $p 
#		Write-Output $LASTEXITCODE
#	}
#	
}
}
}
}

$baseFolder = 'X:\PDMT\2014\Shape\Test'
$tmpFolder = 'G:\temp\ogrmerge'
$outFolder = 'G:\ManglendeDataMergedOut'
$logFile = 'c:\temp\ShapeMergeOgr.log'

if(Test-Path $logFile)
{
	Remove-Item $logFile
}

if(!(Test-Path $outFolder))
		{
			New-Item -ItemType directory -Path $outFolder
		}
Get-ChildItem -Path ($tmpFolder + '\*') | Remove-Item -Force
$dataDirs = Get-ChildItem $baseFolder -Recurse | where { $_.PSIsContainer } 

foreach($dir in $dataDirs)
{

if ((@(Get-ChildItem ($dir.fullname +'\*') -Include *.shp)).count -ge 1 )
	{
	
		Merge-ShpFiles -files @(Get-ChildItem ($dir.FullName + '\*') -Include *_polygon.shp) -type '_pol' -nlt 'POLYGON'
		Merge-ShpFiles -files @(Get-ChildItem ($dir.FullName + '\*') -Include *_line.shp) -type '_lin' -nlt 'LINESTRING'
		Merge-ShpFiles -files @(Get-ChildItem ($dir.FullName + '\*') -Include *_point.shp) -type '_pnt' -nlt 'POINT'

		New-Item $dir.FullName.Replace($baseFolder, $outFolder) -ItemType directory -Force
		$mergedFiles = Get-ChildItem -Path ($tmpFolder + '\*') | select -ExpandProperty fullname
		if($mergedFiles.count -gt 0)
		{
		Copy-Item -Path $mergedFiles -Destination ($dir.FullName.Replace($baseFolder, $outFolder)) -Force
		Remove-Item $mergedFiles -Recurse -Force 
		While((Get-ChildItem -Path ($tmpFolder + '\*')).count -gt 0)
		{
			Get-ChildItem -Path ($tmpFolder + '\*') | Remove-Item -Force
		}
		}
		
	}
}